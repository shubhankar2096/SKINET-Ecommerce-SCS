﻿using Core.Entities;
using Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Data
{
    public class ProductRepository : IProductRepository
    {
        private readonly StoreContext _context;
        public ProductRepository(StoreContext context)
        {
            _context = context;
        }

        public async Task<Product> GetProductByIDAsync(int id)
        {
            //var product = await _context.Products.Where(p => p.Id == id).FirstOrDefaultAsync();
            //var product = await _context.Products.FindAsync(id);
            var product = await _context.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductBrand)
                .FirstOrDefaultAsync(p => p.Id == id);
            return product;
        }

        public async Task<IReadOnlyList<Product>> GetProductListAsync()
        {
                // If we don't use Include, it will return NULL for productType and productBrand
                //Include works like JOIN
                /*
                 {
                    "name": "Green Angular Board 3000",
                    "description": "Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.",
                    "price": 150.00,
                    "pictureURL": "images/products/sb-ang2.png",
                    "productType": null,
                    "productTypeId": 1,
                    "productBrand": null,
                    "productBrandId": 1,
                    "id": 2
                  }
                 */
            var products = await _context.Products               
                .Include(p => p.ProductType) 
                .Include(p => p.ProductBrand)
                .ToListAsync();
            return products;
        }

        public async Task<IReadOnlyList<ProductBrand>> GetProductBrandsListAsync()
        {
            var productBrands = await _context.ProductBrands.ToListAsync();
            return productBrands;
        }

        public async Task<IReadOnlyList<ProductType>> GetProductTypesListAsync()
        {
            var productTypes = await _context.ProductTypes.ToListAsync();
            return productTypes;
        }
    }
}
